import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, LayoutGrid, Send, Bot, PenSquare, CalendarDays } from "lucide-react";
import { ThemeToggle, useTheme } from "@/components/ThemeToggle";
import { PhonePreview } from "@/components/PhonePreview";
import { QuickCreationTab } from "@/components/tabs/QuickCreationTab";
import { MediaStudioTab } from "@/components/tabs/MediaStudioTab";
import { DistributionTab } from "@/components/tabs/DistributionTab";
import { PostGeneratorTab } from "@/components/tabs/PostGeneratorTab";
import { CalendarTab } from "@/components/tabs/CalendarTab";

const Index = () => {
  const { theme, setTheme } = useTheme();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Ambient gradient backdrop */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-32 left-1/4 h-96 w-96 rounded-full bg-primary/15 blur-3xl" />
        <div className="absolute right-1/4 top-1/3 h-96 w-96 rounded-full bg-accent/10 blur-3xl" />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1600px] items-center justify-between gap-4 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground shadow-glow">
              <Bot className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-foreground">
                Marketing IA Hub
              </h1>
              <p className="text-xs text-muted-foreground">OmniGestão Pro · Estúdio Enterprise</p>
            </div>
          </div>
          <ThemeToggle theme={theme} onChange={setTheme} />
        </div>
      </header>

      {/* Main asymmetric grid */}
      <main className="mx-auto max-w-[1600px] px-6 py-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
          {/* LEFT: Cockpit */}
          <section className="lg:col-span-8">
            <Tabs defaultValue="quick" className="w-full">
              <TabsList className="mb-6 grid h-auto w-full grid-cols-2 gap-1 rounded-2xl border border-border bg-card/60 p-1.5 backdrop-blur-md sm:grid-cols-3 lg:grid-cols-5">
                <TabsTrigger
                  value="quick"
                  className="flex items-center gap-2 rounded-xl py-3 text-sm font-medium data-[state=active]:bg-gradient-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-glow"
                >
                  <Sparkles className="h-4 w-4" />
                  <span className="hidden md:inline">Criação</span>
                  <span className="md:hidden">Criar</span>
                </TabsTrigger>
                <TabsTrigger
                  value="posts"
                  className="flex items-center gap-2 rounded-xl py-3 text-sm font-medium data-[state=active]:bg-gradient-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-glow"
                >
                  <PenSquare className="h-4 w-4" />
                  <span className="hidden md:inline">Posts</span>
                  <span className="md:hidden">Posts</span>
                </TabsTrigger>
                <TabsTrigger
                  value="studio"
                  className="flex items-center gap-2 rounded-xl py-3 text-sm font-medium data-[state=active]:bg-gradient-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-glow"
                >
                  <LayoutGrid className="h-4 w-4" />
                  <span className="hidden md:inline">Estúdio</span>
                  <span className="md:hidden">Mídia</span>
                </TabsTrigger>
                <TabsTrigger
                  value="calendar"
                  className="flex items-center gap-2 rounded-xl py-3 text-sm font-medium data-[state=active]:bg-gradient-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-glow"
                >
                  <CalendarDays className="h-4 w-4" />
                  <span className="hidden md:inline">Calendário</span>
                  <span className="md:hidden">Cal.</span>
                </TabsTrigger>
                <TabsTrigger
                  value="dist"
                  className="flex items-center gap-2 rounded-xl py-3 text-sm font-medium data-[state=active]:bg-gradient-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-glow"
                >
                  <Send className="h-4 w-4" />
                  <span className="hidden md:inline">Distribuição</span>
                  <span className="md:hidden">Hub</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="quick" className="mt-0 focus-visible:outline-none">
                <QuickCreationTab />
              </TabsContent>
              <TabsContent value="posts" className="mt-0 focus-visible:outline-none">
                <PostGeneratorTab />
              </TabsContent>
              <TabsContent value="studio" className="mt-0 focus-visible:outline-none">
                <MediaStudioTab />
              </TabsContent>
              <TabsContent value="calendar" className="mt-0 focus-visible:outline-none">
                <CalendarTab />
              </TabsContent>
              <TabsContent value="dist" className="mt-0 focus-visible:outline-none">
                <DistributionTab />
              </TabsContent>
            </Tabs>
          </section>

          {/* RIGHT: Sticky phone preview */}
          <aside className="lg:col-span-4">
            <div className="lg:sticky lg:top-24">
              <div className="mb-4 text-center">
                <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                  Pré-visualização em tempo real
                </p>
                <h3 className="mt-1 text-xl font-bold gradient-text">Seu próximo Reel</h3>
              </div>
              <PhonePreview />
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
};

export default Index;
