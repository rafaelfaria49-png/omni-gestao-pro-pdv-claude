import { useEffect } from "react";
import { useTheme as useNextTheme } from "next-themes";
import { Sun, Snowflake, Moon, CircleDot } from "lucide-react";
import { cn } from "@/lib/utils";

export type ThemeKey = "light" | "soft-ice" | "midnight" | "black";

const THEMES: { key: ThemeKey; label: string; icon: typeof Sun }[] = [
  { key: "light", label: "Light", icon: Sun },
  { key: "soft-ice", label: "Soft Ice", icon: Snowflake },
  { key: "midnight", label: "Midnight", icon: Moon },
  { key: "black", label: "Black", icon: CircleDot },
];

const STORAGE_KEY = "mhub-theme";
const ALL_CLASSES = THEMES.map((t) => `theme-${t.key}`);

const isThemeKey = (value?: string): value is ThemeKey =>
  THEMES.some((theme) => theme.key === value);

function applyTheme(theme: ThemeKey) {
  const root = document.documentElement;
  const body = document.body;
  const isDarkTheme = theme === "midnight" || theme === "black";

  ALL_CLASSES.forEach((c) => {
    root.classList.remove(c);
    body?.classList.remove(c);
  });
  root.classList.remove("light", "dark");
  root.classList.add(`theme-${theme}`);
  root.classList.add(isDarkTheme ? "dark" : "light");
  body?.classList.add(`theme-${theme}`);
  root.setAttribute("data-theme", theme);
  root.style.colorScheme = isDarkTheme ? "dark" : "light";
}

export function useTheme() {
  const { theme: nextTheme, setTheme: setNextTheme, resolvedTheme } = useNextTheme();
  const theme = isThemeKey(nextTheme) ? nextTheme : "midnight";

  useEffect(() => {
    applyTheme(theme);
  }, [resolvedTheme, theme]);

  const setTheme = (t: ThemeKey) => {
    applyTheme(t); // apply immediately on click for instant feedback
    setNextTheme(t);
    try {
      window.localStorage.setItem(STORAGE_KEY, t);
    } catch {
      // ignore
    }
  };

  return { theme, setTheme };
}

interface Props {
  theme: ThemeKey;
  onChange: (t: ThemeKey) => void;
}

export const ThemeToggle = ({ theme, onChange }: Props) => {
  return (
    <div className="inline-flex items-center gap-1 rounded-full border border-border bg-card/60 p-1 backdrop-blur-md shadow-elegant">
      {THEMES.map(({ key, label, icon: Icon }) => {
        const active = theme === key;
        return (
          <button
            key={key}
            type="button"
            onClick={() => onChange(key)}
            className={cn(
              "group flex items-center gap-2 rounded-full px-3 py-2 text-sm font-medium transition-all",
              active
                ? "bg-gradient-primary text-primary-foreground shadow-glow"
                : "text-muted-foreground hover:text-foreground hover:bg-muted"
            )}
            aria-pressed={active}
            aria-label={`Tema ${label}`}
          >
            <Icon className="h-4 w-4" />
            <span className="hidden sm:inline">{label}</span>
          </button>
        );
      })}
    </div>
  );
};
