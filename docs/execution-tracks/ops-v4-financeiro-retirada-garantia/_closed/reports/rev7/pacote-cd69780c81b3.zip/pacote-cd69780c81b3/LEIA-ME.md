# Pacote imutável — GOAL 002 revisão 7

Candidato: cd69780c81b3bc159cd5f0810daabc98aae06a34. Base ratificada: 60337ff116e831e1e7e13597a4e6622a6df131ed. Executor OpenAI, C4 ALTO por exceção humana registrada na TRACK. R obrigatoriamente Anthropic ou humano qualificado, analisando TODO o conjunto funcional A–E e os corretivos dos P1. Este pacote não é uma aprovação.

## Ordem de leitura

1. GOAL-rev7.md, TRACK.md, EXECUTORES.json, candidate.txt e AEP-active-snapshot.json.
2. diff-funcional.patch INTEGRAL contra a base; diff-completo.patch inclui também toda a evidência/documentação. Não limitar a revisão ao último commit. A fonte atual na worktree está no SHA exato; nenhum arquivo de produto difere de b617dcc.
3. evidencias-revisionadas/veredito-r1.md, r2 e r3, pacote-r3.md e RED-BASELINE.md. São REQUEST_CHANGES OpenAI anteriores sobre a implementação Anthropic; não servem de R deste candidato.
4. validacao/COBERTURA-final.md (24 cenários), aep-check-attempt3.json/log, build-final.json, lint e verify.
5. Demais testes, regressões, baseline e contagens financeiras. Os logs e JSON identificam as execuções históricas; equivalência de produto e escopo estão no candidate-audit-final.json.

## Diagnóstico e implementação

P1-A: mensagem/digest de exceção era usada como prova de não gravação. Toda exceção agora permanece incerta. Resposta moderna positiva exige prova e reconhecimento autenticado. Recusa definitiva é persistida sob advisory e a mesma serialização, após rollback das escritas da tentativa, impedindo uma requisição atrasada de gravar posteriormente. Leitura vazia nunca comprova ausência.

P1-B: imediato e misto tinham pendências separadas e admitiam outra chave/modalidade depois da resposta perdida. Agora o envelope único por [storeId, osId] guarda ID e input completo antes do await, persiste no navegador e no MESMO commit financeiro. Outra chave/conteúdo/modalidade/a prazo/estorno permanece bloqueado. Replays precedem elegibilidade, estado atual do caixa e fence de outra confirmação. Reconhecimento exige ID, modalidade e fingerprint sob auth/travas. LocalStorage não é autoridade financeira; não há expiração da incerteza.

A UI oferece Verificar mesma confirmação. Reenvio canonicamente equivalente do PDV V3 usa sempre o input original congelado (PIX 100 = PIX 50 + PIX 50); outro conteúdo fica bloqueado. Remount/refresh e troca rápida de OS/loja não transferem o resultado para o alvo novo. Dados inválidos e permissões insuficientes mantêm a conferência pendente.

## Provas e resultados

- Antes: 11 montados falham; PG reproduz duas baixas de 100, dois caixas/movimentos e parcela 220 após uma resposta perdida.
- Depois: 109 específicos, com PostgreSQL real, autores autenticados distintos, lock observado por pg_stat_activity, confirmações negativas duráveis, fotos título/baixa/caixa/mov/a prazo/OS e input original. Split 100 Pix + 70 Dinheiro + 250 a prazo = 420: uma baixa agregada 170, duas operações de caixa (uma por forma), uma movimentação agregada e uma parcela/título únicos.
- Check oficial da tentativa 3 sobre cd69780: PASS. O comando exato está no JSON. Ele executa 809 Vitest (493 núcleo + 20 preview selecionados + 109 específicos + 76 GOAL001 + 52 fluxo006 + 20 V3 + 29 V4 + 10 datas) e 9 Playwright (8 cenários + autenticação), sem retries. A CLI retém os detalhes dos subprocessos e imprime o resumo PASS; as contagens são conferidas pelos conjuntos e logs das suítes, sem inventar stdout que a CLI não exporta.
- Typecheck, ESLint dos 44 alterados, build local seguro (MIGRATION_SKIPPED), diff --check, verify e verify --all PASS. Dois previews Vercel verdes não são publicação em produção.
- Regressões externas: fluxo001 29; fluxo002 15 montados + 1 PG; fluxo003 4; fluxo004 45; fluxo005 47; fluxo006 70; #234/#238 PG109; #235 PG1; #237 PG34. Montados pertinentes no check oficial.
- E2E GOAL001 6/6 e fluxo006 16/16 em ec3b5cf. Depois, único fonte de produto alterado foi PDV V3, verificado em b617dcc pelo E2E misto 5/6: #238 C/D e #234 passam, apenas a falha conhecida #235 continua. Produto de cd69780 é idêntico a b617dcc.

## Falhas preexistentes e histórico de tentativas

Baseline 98ef717 é ancestral da main60337; caminhos operacionais/E2E são byte a byte idênticos nessa comparação. Seis arquivos lib/pessoas evoluíram independentemente, portanto não se alega equivalência do repositório inteiro.

- Full preview: base321 PASS10 FAIL; candidato325 PASS nos mesmos10 FAIL. Filtro oficial20/20 verde.
- Fluxo007: 66 PASS1 FAIL T56c, falha isolada reproduzida3/3 em cada lado; fonte/action teste idênticos. A base também passou67 uma vez, mostrando ordenação por timer; nenhuma edição fora da allowlist.
- E2E #235: base/candidato5 PASS1 FAIL na MESMA busca do texto Recebido nesta operação.
- E2E #237: base/candidato5 PASS1 FAIL na MESMA mensagem de entrega contendo retirante.
- Não se declaram essas suítes integralmente verdes. Não houve remoção de asserção financeira, novos skips/fixmes, retries ou edição de teste fora da allowlist.
- Tentativa1: fixture E2E misto fotografava antes do commit; barreira route.fetch + abort + contagens corrigida. Tentativa2: teste montado avançava entre persistência local e resposta e entre reconciliação e efeito do saldo. Ambas registradas pela CLI, sem reset. Teste final controla as duas promises, valida bloqueio em voo e aguarda saldo antes da próxima digitação. Logs intermediários, inclusive falhas, preservados. Arquivos attempt3-v3-green-3.log e nomes similares contêm falha histórica; nomes não são veredito.
- .last-run copiado ao fim do check2 era obsoleto porque Playwright não foi alcançado; excluído deste pacote. O resultado Playwright do check3 é o run real concluído.

## Integridade e gate

MANIFEST.json contém SHA-256 de cada arquivo do pacote (exceto o próprio manifesto). O SHA do manifesto e do ZIP externo são registrados separadamente. Não alterar este diretório depois da selagem. Nova revisão em sessão real Anthropic ou humano: SHA exato, identidade/família/modelo, P0/P1/P2/P3 e VERDICT verdadeiro. Só APPROVE e P0=P1=P2=0 autorizam close separado, PR/merge normal e publicação.

Nenhuma migration, schema, auth/proxy/motor global ou dado produtivo alterado. OS-2026-00025 intocada. GOAL003/008 não iniciados. Worktree -002-base e junction preservados. BLOCKED externo anterior íntegro.
