# Matriz de segurança — SHA cd69780c81b3bc159cd5f0810daabc98aae06a34

As referências abaixo indicam testes existentes. O resultado final depende dos logs do AEP check e E2E; referência não é veredito R.

| Nº | Cenário | Evidência |
|---|---|---|
| 1 | Pagamento gravado e resposta perdida | PG: imediato incerto seguido de misto; replay devolve recibo original. E2E R7 imediato/misto aborta resposta depois de route.fetch() (commit real). |
| 2 | Connection closed. sem digest | Montado it.each: mantém identidade e conteúdo após Connection closed. sem digest. |
| 3 | Timeout antes da resposta | Montado it.each: mantém identidade e conteúdo após timeout. |
| 4 | Transação processando durante segunda tentativa | PG: segunda chave durante transação ainda em processamento ESPERA o lock; barreira explícita + pg_stat_activity. |
| 5 | Permissão negada antes do replay | Montado it.each e PG: permissão negada antes do replay mantém fence. |
| 6 | Permissão alterada após primeira tentativa | Montado: permissão alterada no reenvio; PG restaura permissão e recupera operação original. |
| 7 | Mesma operação e fingerprint | PG: replay devolve recibo e operação originais; comparações de conteúdo completo. |
| 8 | Mesma operacaoId com conteúdo diferente | PG: variantes forma/valor/sessão/saldo/intenção/observação conflitantes, foto financeira igual. |
| 9 | Imediato incerto e outra forma | Montado: alteração de forma/valor/sessão não dispara outra operação. PG fingerprint conflitante. |
| 10 | Imediato incerto e misto | Montado: imediato gravado/resposta perdida bloqueia misto; PG duas chaves, uma baixa. |
| 11 | Misto incerto e imediato | Montado: misto incerto bloqueia imediato; PG split original bloqueia imediato. |
| 12 | Misto incerto e outro misto | PG: split original bloqueia outro misto até reconhecer; montado input divergente não enviado. |
| 13 | Alteração valor/sessão/forma/vencimento | Montados parametrizados de conteúdo misto e imediato; PG fingerprints conflitantes preservam foto financeira. |
| 14 | Troca rápida de OS | Montados: resultado tardio de imediato/misto não aparece na nova OS; superfícies e fluxo-hook. |
| 15 | Troca de loja com resposta atrasada | Montados parametrizados OS/loja: resposta tardia não atualiza alvo novo. PG prova de outra loja recusada. |
| 16 | Fechar/reabrir modal | E2E R7 imediato/misto fecha e reabre antes de refresh; montados do sheet preservam input. |
| 17 | Remount e refresh | Montado remount/refresh conserva confirmação; servidor restaura pendência sem localStorage. E2E recarrega navegador real. |
| 18 | Duplo clique | Montado duplo clique envia UMA vez antes de await. PG dois replays concorrentes, uma baixa. |
| 19 | Dois operadores concorrentes | PG duas sessões autenticadas com IDs e nomes distintos, writers reais, sob advisory, barreira + inspeção real de lock e contagens. Montado duas instâncias/evento storage. |
| 20 | Terminal libera nova operação | Montado recusa terminal da mesma identidade libera NOVA confirmação. PG recusa durável não grava após reabrir caixa e nova chave legítima grava. |
| 21 | Gravado recuperado sem segunda baixa | PG fotos antes/depois, título/baixa/caixa/mov/OS e recibo original. E2E replay usa exatamente JSON original. |
| 22 | Caixa fechado depois do original | PG: caixa fechado depois do commit não bloqueia replay nem reconhecimento. |
| 23 | Estorno posterior e nova cobrança | PG: estorno não transforma replay antigo em nova cobrança; nova identidade distinguível e saldo correto. |
| 24 | Pix + Dinheiro + a prazo | PG: 100 Pix + 70 Dinheiro + 250 a prazo = 420; uma baixa agregada de 170, duas operações caixa (uma por forma), uma movimentação agregada, uma parcela, título único. |

## Callers e compatibilidade

- Hook usePdvServicoV3: caller cliente único dos writers imediato e misto. Envia opt-in confirmacaoClienteV3: true, preservando o input original.
- PdvServicoV3: consome o mesmo hook; bloqueia as duas modalidades e estorno.
- useV4Preview: consome o mesmo hook fora do sheet; fechamento/remount do sheet preserva pendência. O wrapper de verificar atualiza lista/detalhe/projeção somente para o alvo capturado. ReceberPagamentoV4 bloqueia também atalho a prazo.
- atendimento-rapido-actions.ts: caller server-side legado de receberOSV3. O tipo genérico condicional mantém seu retorno/erros anteriores; teste PG de atendimento rápido continua passando.
- Lancar a prazo e estornar: mantêm seus contratos; conferem o mesmo fence antes de nova escrita. Replay a prazo já gravado precede fence/estado do período.
- Leitura/reconhecimento lerPagamentoOSV3: terceiro argumento opcional aditivo com prova positiva; read comum nunca apaga pendência. Auth/loja e permissões são revalidadas antes de expor ou reconhecer metadados.

## Limites declarados

A exclusão emVoo é síncrona entre instâncias do mesmo documento; abas recebem storage events, mas o bloqueio final é o fence sob advisory no banco. localStorage não é autoridade financeira. O servidor só libera a pendência quando recebe prova autenticada exata, ou devolve uma recusa negativa persistida sob a mesma serialização. Não há expiração que transforme incerteza em ausência. Metadado ilegível/permissão insuficiente exige conferência autorizada. Nenhuma promessa de que um read vazio comprova rollback.
