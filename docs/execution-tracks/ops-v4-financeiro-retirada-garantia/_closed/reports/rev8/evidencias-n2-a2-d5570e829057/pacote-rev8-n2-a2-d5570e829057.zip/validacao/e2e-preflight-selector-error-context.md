# Test info

- Name: N2 — recusa mista real preserva motivo e destino PRECO_AUSENTE → comercial
- Location: C:\Projetos\omni-gestao-ops-v4-frg-002\e2e\specs\ops-v4-financeiro-retirada-garantia-002.spec.ts:488:7

# Error details

```
Error: Timed out 25000ms waiting for expect(locator).toBeVisible()

Locator: getByText('Esta OS não tem valor a cobrar. Gere e aprove o orçamento antes de receber.', { exact: true })
Expected: visible
Received: <element(s) not found>
Call log:
  - expect.toBeVisible with timeout 25000ms
  - waiting for getByText('Esta OS não tem valor a cobrar. Gere e aprove o orçamento antes de receber.', { exact: true })

    at C:\Projetos\omni-gestao-ops-v4-frg-002\e2e\specs\ops-v4-financeiro-retirada-garantia-002.spec.ts:505:132
```

# Page snapshot

```yaml
- complementary "Navegação principal":
  - button "Expandir menu":
    - img "OmniGestão"
  - text: OmniGestão Pro Workspace em foco
  - navigation:
    - text: Workspace
    - link "Painel Inicial":
      - /url: /dashboard
    - link "IA Mestre":
      - /url: /dashboard/ia-mestre
    - link "Omni Agent HUB":
      - /url: /dashboard/omni-agent
    - text: Hubs
    - link "Operações HUB":
      - /url: /dashboard/operacoes-v3
    - link "Operações V4 · Beta":
      - /url: /dashboard/operacoes-v4-preview
    - link "Operações V2":
      - /url: /dashboard/operacoes-v2
    - link "WhatsApp HUB":
      - /url: /dashboard/whatsapp
    - link "Cadastros HUB":
      - /url: /dashboard/cadastros-v2
    - link "Inventário Assistido":
      - /url: /dashboard/estoque/inventario
    - link "Catálogo de Aparelhos":
      - /url: /dashboard/catalogo-aparelhos
    - link "Vendas HUB":
      - /url: /dashboard/vendas-hub
    - link "Histórico de Caixa":
      - /url: /dashboard/caixa/historico
    - link "Financeiro HUB":
      - /url: /dashboard/financeiro-v2
    - link "Contador HUB":
      - /url: /dashboard/contador
    - link "Relatórios":
      - /url: /dashboard/relatorios
    - text: Administração
    - link "Master Console":
      - /url: /dashboard/master-console
    - link "Gestão da Rede":
      - /url: /dashboard/unidades
    - link "Configurações":
      - /url: /dashboard/configuracoes
  - text: Servidor conectado
- banner:
  - navigation: Matriz / Central de Operações
  - textbox "Pesquisa rápida (Alt+K) — Command Menu"
  - text: ⌘K
  - 'button "Tema atual: Black. Abrir seletor de temas"'
  - button "Alta legibilidade"
  - link "Sem créditos. Abrir consulta e compra de créditos":
    - /url: /dashboard/creditos
    - text: Sem créditos Comprar
  - button
  - button "Novo"
  - text: OF Operador QA FRG qa-frg-002@omni.test
  - heading "Buscar Rota ou Ação" [level=2]
  - paragraph: Digite um comando de navegação para executar rápido.
- main:
  - text: O OmniGestão Operações V4 · Beta operacional
  - button "Ir para OS, cliente, IMEI… ⌘K":
    - img
    - text: Ir para OS, cliente, IMEI… ⌘K
  - button "Sair do foco":
    - img
    - text: Sair do foco
  - text: Loja ativa
  - button "+ Novo"
  - complementary "Módulos de Operações V4":
    - button "Expandir módulos": V4
    - text: OPERAÇÕES
    - button "Visão geral":
      - img
      - text: Visão geral
    - button "Fila":
      - img
      - text: Fila
    - button "OS":
      - img
      - text: OS
    - button "Bancada":
      - img
      - text: Bancada
    - button "SLA":
      - img
      - text: SLA
    - button "Receber":
      - img
      - text: Receber
    - button "Garantias":
      - img
      - text: Garantias
    - button "Configurações":
      - img
      - text: Configurações
  - button "Contexto da OS"
  - heading "OS-QA-FRG2-mv42qe1v1" [level=1]
  - text: Pronta
  - button "Técnico Sem técnico"
  - button "Prioridade Normal"
  - button "Comercial Cobrança não definida"
  - button "Financeiro Sem Conta a Receber Financeiro"
  - button "Pós-venda Garantia 90 dias"
  - button "Docs ▾"
  - button "Histórico 1 evento"
  - button "⋯"
  - navigation "Pipeline operacional da OS":
    - button "✓ Entrada"
    - button "✓ Diagnóstico"
    - button "✓ Execução"
    - button "● Entrega"
    - button "05 Pós-venda"
  - region "Próxima ação da OS":
    - paragraph: Revisar Definir cobrança
    - paragraph: Esta OS não tem preço confiável definido. Defina a cobrança antes de entregar.
    - button "Abrir orçamento"
  - text: Financeiro da OS OS-QA-FRG2-mv42qe1v1 Cliente QA FRG2 mv42qe1v1 Aprovação pendente Total R$ 0,00 Recebido Indisponível Saldo Indisponível
  - strong: Preço não definido — definir cobrança
  - button "Abrir orçamento"
  - text: Conta a Receber Não criada Forma de pagamento Não registrada
  - alert:
    - paragraph: "Recebimento recusado: esta OS não tem preço aprovado. Gere e aprove o orçamento antes de receber."
    - button "Conferir orçamento →"
  - text: Esta OS não tem valor a cobrar. Gere e aprove o orçamento antes de receber. Histórico de recebimentos Nenhum recebimento registrado nesta OS.
  - complementary "Atividade da OS":
    - button "Expandir atividade da OS"
    - text: ATIVIDADE DA OS ATIVIDADE
    - paragraph: Comunicação, anexos e histórico relacionados à OS atual.
    - text: Comunicação
    - button "Enviar atualização no WhatsApp"
    - text: Anexos 0 Nenhum anexo disponível.
    - button "Abrir histórico do cliente"
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  405 |     });
  406 |     await sheet.getByRole("button", { name: modalidade === "misto" ? /^Registrar R\$\s100,00/ : /^Confirmar R\$\s100,00$/ }).click();
  407 |     await expect(sheet.getByRole("alert")).toContainText("Confirmação pendente de verificação.", IDA_E_VOLTA);
  408 |     // O aviso local aparece antes de a requisição terminar: a foto exige o commit REAL.
  409 |     await expect.poll(() => respostaPerdidaConcluida, IDA_E_VOLTA).toBe(true);
  410 |     await expect.poll(() => envios.length).toBe(1);
  411 |     const titulosAntes = await titulosDe(prisma, os.id), caixaAntes = await caixaDaOS(prisma, os.id);
  412 |     expect(titulosAntes).toHaveLength(1); expect(caixaAntes).toHaveLength(1);
  413 |     const antes = JSON.stringify({ titulos: titulosAntes, caixa: caixaAntes });
  414 |     await sheet.getByRole("button", { name: "Fechar recebimento" }).click();
  415 |     await page.getByRole("button", { name: "Verificar mesma confirmação", exact: true }).click();
  416 |     sheet = page.getByRole("dialog", { name: "Receber pagamento" });
  417 |     await expect(sheet.getByLabel("Forma da linha 1")).toBeDisabled();
  418 |     await expect(sheet.getByLabel("Forma da linha 1")).toHaveValue("pix");
  419 |     await page.reload();
  420 |     await abrirOS(page, os.codigo); await ticketFinanceiro(page).click();
  421 |     await page.getByRole("button", { name: "Verificar mesma confirmação", exact: true }).click();
  422 |     sheet = page.getByRole("dialog", { name: "Receber pagamento" });
  423 |     await expect(sheet.getByLabel("Valor da linha 1")).toHaveValue("100");
  424 |     await expect(sheet.getByRole("button", { name: "+ Dividir pagamento" })).toBeDisabled();
  425 |     await sheet.getByRole("button", { name: "Verificar mesma confirmação", exact: true }).click();
  426 |     await expect(sheet).toBeHidden(IDA_E_VOLTA);
  427 |     expect(envios).toHaveLength(2); expect(JSON.parse(envios[1]!)).toEqual(JSON.parse(envios[0]!));
  428 |     expect(JSON.stringify({ titulos: await titulosDe(prisma, os.id), caixa: await caixaDaOS(prisma, os.id) })).toBe(antes);
  429 |     const titulo = (await titulosDe(prisma, os.id))[0]!;
  430 |     const historico = ((titulo.payload as { historico: Array<{ tipo: string; valor: number }> }).historico).filter((e) => e.tipo === "pagamento" || e.tipo === "liquidacao");
  431 |     expect(historico.map((e) => e.valor)).toEqual([100]);
  432 |     expect(await prisma.ordemServico.count({ where: { id: os.id, storeId: LOJA } })).toBe(1);
  433 |     expect((await linhaOS(prisma, os.id)).payload.confirmacaoRecebimentoPendenteV3).toBeUndefined();
  434 |   });
  435 | }
  436 |
  437 |
  438 | for (const destino of ["comercial", "financeiro"] as const) {
  439 |   test(`R8 — recusa imediata real preserva motivo, navega para ${destino} e permite nova confirmação após resolução`, async ({ page }) => {
  440 |     const os = await semearOS(prisma, "aprovado", false);
  441 |     await abrirOS(page, os.codigo); await ticketFinanceiro(page).click();
  442 |     await page.getByRole("button", { name: /^Receber R\$\s420,00$/ }).click();
  443 |     let sheet = page.getByRole("dialog", { name: "Receber pagamento" });
  444 |     await sheet.getByRole("button", { name: "Pagamento parcial", exact: true }).click();
  445 |     await sheet.getByLabel("Forma da linha 1").selectOption("pix");
  446 |     await sheet.getByLabel("Valor da linha 1").fill("100");
  447 |     await sheet.getByLabel("Observação (opcional)").fill("Rascunho R8 preservado");
  448 |     // Mudança concorrente no QA: o navegador continua com a leitura aprovada anterior.
  449 |     const row = await linhaOS(prisma, os.id);
  450 |     const alterado = destino === "comercial" ? { ...row.payload, orcamento: { ...row.payload.orcamento, status: "rascunho" } } : row.payload;
  451 |     await prisma.ordemServico.update({ where: { id: os.id }, data: { payload: alterado as unknown as Prisma.InputJsonValue, valorTotal: destino === "financeiro" ? 400 : 420 } });
  452 |     const antesFinanceiro = JSON.stringify({ titulos: await titulosDe(prisma, os.id), caixa: await caixaDaOS(prisma, os.id), timeline: (await linhaOS(prisma, os.id)).payload.timeline });
  453 |     await sheet.getByRole("button", { name: /^Confirmar R\$\s100,00$/ }).click();
  454 |     const aviso = sheet.getByTestId("recusa-comercial");
  455 |     await expect(aviso).toContainText(destino === "comercial" ? "o orçamento ainda não foi aprovado" : "os valores desta OS não conferem entre si", IDA_E_VOLTA);
  456 |     await expect(sheet.getByLabel("Observação (opcional)")).toHaveValue("Rascunho R8 preservado");
  457 |     await expect(sheet.getByRole("button", { name: /^Confirmar R\$\s100,00$/ })).toBeEnabled();
  458 |     const recusas = (await linhaOS(prisma, os.id)).payload.recebimentoImediatoRecusasV3 as Array<{ operacaoId: string; comercial: { codigo: string; destino: string } }>;
  459 |     expect(recusas).toHaveLength(1);
  460 |     expect(recusas[0]!.comercial).toEqual({ codigo: destino === "comercial" ? "APROVACAO_COMERCIAL_PENDENTE" : "VALORES_DIVERGENTES", destino });
  461 |     expect(JSON.stringify({ titulos: await titulosDe(prisma, os.id), caixa: await caixaDaOS(prisma, os.id), timeline: (await linhaOS(prisma, os.id)).payload.timeline })).toBe(antesFinanceiro);
  462 |     const antesNav = await efeitos(prisma, os.id);
  463 |     await aviso.getByRole("button", { name: destino === "comercial" ? "Conferir orçamento →" : "Conferir cobrança →" }).click();
  464 |     await expect(sheet).toBeHidden();
  465 |     await expect(destino === "comercial" ? ticketComercial(page) : ticketFinanceiro(page)).toHaveAttribute("aria-current", "page");
  466 |     expect(await efeitos(prisma, os.id)).toBe(antesNav);
  467 |     const chaves = await page.evaluate(() => Object.keys(localStorage).filter(k => k.startsWith("omni:confirmacao-financeira:v1:")));
  468 |     expect(chaves.filter(k => k.includes(os.id))).toHaveLength(0);
  469 |     // Resolução sintética, sem aprovar/cobrar pelo atalho: a próxima operação é NOVA.
  470 |     const recusada = await linhaOS(prisma, os.id);
  471 |     await prisma.ordemServico.update({ where: { id: os.id }, data: { valorTotal: 420, payload: { ...recusada.payload, orcamento: { ...recusada.payload.orcamento, status: "aprovado" } } as unknown as Prisma.InputJsonValue } });
  472 |     await abrirOS(page, os.codigo); await ticketFinanceiro(page).click();
  473 |     await page.getByRole("button", { name: /^Receber R\$\s420,00$/ }).click();
  474 |     sheet = page.getByRole("dialog", { name: "Receber pagamento" });
  475 |     await expect(sheet.getByTestId("recusa-comercial")).toHaveCount(0);
  476 |     await sheet.getByRole("button", { name: "Pagamento parcial", exact: true }).click();
  477 |     await sheet.getByLabel("Forma da linha 1").selectOption("pix"); await sheet.getByLabel("Valor da linha 1").fill("100");
  478 |     await sheet.getByRole("button", { name: /^Confirmar R\$\s100,00$/ }).click(); await expect(sheet).toBeHidden(IDA_E_VOLTA);
  479 |     const caixa = await caixaDaOS(prisma, os.id); expect(caixa).toHaveLength(1); expect(caixa[0]!.valor).toBe(100);
  480 |     expect((caixa[0]!.payload as { operacaoId: string }).operacaoId).not.toBe(recusas[0]!.operacaoId);
  481 |     expect((await linhaOS(prisma, os.id)).payload.recebimentoImediatoRecusasV3).toEqual(recusas);
  482 |     expect(await titulosDe(prisma, os.id)).toHaveLength(1);
  483 |   });
  484 | }
  485 |
  486 |
  487 | for (const [codigo, destino] of [["PRECO_AUSENTE", "comercial"], ["APROVACAO_COMERCIAL_PENDENTE", "comercial"], ["VALORES_DIVERGENTES", "financeiro"]] as const) {
  488 |   test("N2 — recusa mista real preserva motivo e destino " + codigo + " → " + destino, async ({ page }) => {
  489 |     const os = await semearOS(prisma, "aprovado", false); await abrirOS(page, os.codigo); await ticketFinanceiro(page).click();
  490 |     await page.getByRole("button", { name: /^Receber R\$\s420,00$/ }).click();
  491 |     const sheet = page.getByRole("dialog", { name: "Receber pagamento" });
  492 |     await sheet.getByLabel("Forma da linha 1").selectOption("pix"); await sheet.getByLabel("Valor da linha 1").fill("100");
  493 |     await sheet.getByRole("button", { name: "+ Dividir pagamento" }).click(); await sheet.getByLabel("Forma da linha 2").selectOption("a_prazo");
  494 |     await sheet.getByLabel("Vencimento da parte a prazo").fill("2099-12-31"); await sheet.getByLabel("Observação (opcional)").fill("Rascunho misto N2 preservado");
  495 |     const row = await linhaOS(prisma, os.id); const { orcamento: _orc, ...semOrcamento } = row.payload;
  496 |     const semPreco = codigo === "PRECO_AUSENTE";
  497 |     const alterado = semPreco ? { ...semOrcamento, valorTotal: 0, servicosCatalogo: [], pecas: [] } : destino === "comercial" ? { ...row.payload, orcamento: { ...row.payload.orcamento, status: "rascunho" } } : row.payload;
  498 |     await prisma.ordemServico.update({ where: { id: os.id }, data: { payload: alterado as unknown as Prisma.InputJsonValue, valorTotal: semPreco ? 0 : destino === "financeiro" ? 400 : 420 } });
  499 |     const antesFinanceiro = JSON.stringify({ titulos: await titulosDe(prisma, os.id), caixa: await caixaDaOS(prisma, os.id), timeline: (await linhaOS(prisma, os.id)).payload.timeline });
  500 |     await sheet.getByRole("button", { name: /^Registrar R\$\s100,00/ }).click(); const aviso = page.getByTestId("recusa-comercial");
  501 |     await expect(aviso).toContainText(destino === "financeiro" ? "os valores desta OS não conferem entre si" : semPreco ? "esta OS não tem preço aprovado" : "o orçamento ainda não foi aprovado", IDA_E_VOLTA);
  502 |     await expect(ticketFinanceiro(page)).toHaveAttribute("aria-current", "page");
  503 |     if (semPreco) {
  504 |       // A releitura autoritativa não oferece saldo inventado: mantém a orientação fora do sheet.
> 505 |       await expect(page.getByText("Esta OS não tem valor a cobrar. Gere e aprove o orçamento antes de receber.", { exact: true })).toBeVisible();
      |                                                                                                                                    ^ Error: Timed out 25000ms waiting for expect(locator).toBeVisible()
  506 |       await expect(sheet).toBeHidden(); await expect(aviso.getByRole("button", { name: "Conferir orçamento →" })).toBeEnabled();
  507 |     } else {
  508 |       await expect(sheet).toBeVisible();
  509 |       await expect(sheet.getByLabel("Observação (opcional)")).toHaveValue("Rascunho misto N2 preservado"); await expect(sheet.getByLabel("Valor da linha 1")).toHaveValue("100");
  510 |       await expect(sheet.getByRole("button", { name: /^Registrar R\$\s100,00/ })).toBeEnabled();
  511 |     }
  512 |     const recusas = (await linhaOS(prisma, os.id)).payload.recebimentoMistoRecusasV3 as Array<{ comercial: { codigo: string; destino: string } }>;
  513 |     expect(recusas).toHaveLength(1); expect(recusas[0]!.comercial).toEqual({ codigo, destino });
  514 |     expect(JSON.stringify({ titulos: await titulosDe(prisma, os.id), caixa: await caixaDaOS(prisma, os.id), timeline: (await linhaOS(prisma, os.id)).payload.timeline })).toBe(antesFinanceiro);
  515 |     const antesNav = await efeitos(prisma, os.id); await aviso.getByRole("button", { name: destino === "comercial" ? "Conferir orçamento →" : "Conferir cobrança →" }).click();
  516 |     await expect(sheet).toBeHidden(); await expect(destino === "comercial" ? ticketComercial(page) : ticketFinanceiro(page)).toHaveAttribute("aria-current", "page"); expect(await efeitos(prisma, os.id)).toBe(antesNav);
  517 |     const chaves = await page.evaluate(() => Object.keys(localStorage).filter(k => k.startsWith("omni:confirmacao-financeira:v1:"))); expect(chaves.filter(k => k.includes(os.id))).toHaveLength(0);
  518 |   });
  519 | }
  520 |
```