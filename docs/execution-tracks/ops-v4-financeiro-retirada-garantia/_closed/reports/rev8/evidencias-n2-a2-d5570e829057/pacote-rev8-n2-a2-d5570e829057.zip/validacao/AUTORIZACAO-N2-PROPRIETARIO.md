# Autorização do proprietário — retomada N2

Transcrição do conteúdo da solicitação humana vigente neste chat, com formatação simplificada, preservada como fonte de autorização. Não é parecer de revisão independente.

# CODEX — GOAL 002 REV8: VERIFICAR E CORRIGIR N2

Continue na worktree C:\Projetos\omni-gestao-ops-v4-frg-002, branch goal/ops-v4-financeiro-retirada-garantia-002.

Candidato anterior:665583a. AEP rev8, tentativa1/3. PR262 continua draft.

O parecer preliminar GLM/Z.ai encontrou P0=0, P1=0, P2=0, P3=8, mas revelou o achado N2.

Verifique o N2 contra o contrato A do GOAL002, que exige no PDV de Serviço V3 mensagem e destino também para recebimento misto.

No candidato, registrarRecebimentoMistoOSV3 devolve comercial={codigo,destino}, mas use-pdv-servico-v3.ts descarta esse campo na recusa mista. A orientação local de PdvServicoV3.tsx cobre apenas alguns códigos. Examine principalmente PRECO_AUSENTE e VALORES_DIVERGENTES.

Se confirmar a falha contratual, trate-a pelo rito AEP como corretivo do MESMO GOAL002, respeitando a revisão8, contador e allowlist. Não replanejar automaticamente nem contornar gates.

Correção mínima esperada:
- Preservar e validar o par comercial canônico também no ramo misto do hook.
- Apresentar o destino correto em V3 e V4, sem navegar automaticamente.
- Manter isolamento por loja/OS/visita e limpar orientação obsoleta.
- Provar recusa inicial, persistência, replay e ausência de efeitos financeiros.
- Preservar os dois P1, fingerprints, locks, CAS, Caixa e idempotência.

Criar testes vermelhos/verdes para misto com destino financeiro e comercial. Executar regressões pertinentes e o check oficial. Não mascarar falhas anteriores.

N1 e N3 permanecem registrados como P3; não ampliar escopo automaticamente.

Após corrigir, congelar novo SHA e preparar uma nova revisão independente completa. O parecer GLM anterior não aprova código alterado e ainda não constitui R oficial.

Não executar close, merge, deploy ou GOAL003 sem R elegível e APPROVE. Preservar PR262 em draft.

Relate: classificação fundamentada de N2, correção realizada ou motivo para não corrigir, testes, AEP, tentativa, novo SHA e próximo gate.
