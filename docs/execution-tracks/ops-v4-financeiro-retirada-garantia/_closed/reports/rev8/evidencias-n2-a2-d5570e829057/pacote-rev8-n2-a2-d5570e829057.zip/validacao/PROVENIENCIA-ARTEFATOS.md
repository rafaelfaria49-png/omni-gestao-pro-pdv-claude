# Proveniência — N2 rev8, tentativa2/3

O objeto final é d5570e829057863a9f670823bb3367b527efb391. As evidências preparatórias não são convertidas em check/R desse SHA. Cada runner informa SHA, exit, comando, horários e alvo QA; os metadados anteriores aos commits também guardam hashes de fontes, pois o produto estava sendo corrigido na árvore de trabalho.

| Evidência | Identidade e limite |
| --- | --- |
| red-summary.json, red-vitest.json, n2-a2-red.* | HEAD documental86cbd77; produto idêntico a665583a; testes novos em trabalho;15 falhas esperadas demonstram N2. expectedRed=false é o campo genérico do modo run do helper; red-summary identifica o propósito explicitamente. |
| green-final-vitest.json, n2-a2-green-final.* | HEAD86cbd77 com corretivo ainda não commitado;36 N2 verdes e hashes do hook corrigido. Preparatório; não é check oficial de86cbd77 ou do SHA final. |
| red-green-crosscheck.json | Todos os15 títulos vermelhos aparecem verdes; a cadeia final reexecuta o conjunto dedicado205. |
| n2-a2-precommit-typecheck.*, precommit-typecheck-invalidada.json | tsc terminou0, mas o runner foi invalidado por troca de HEAD durante a prova. Não contar sucesso; typecheck final está na cadeia ratificada/check. |
| n2-a2-build.*, merge-main.json | Build LOCAL em50d5d55, exit0, MIGRATION_SKIPPED. Código/config/dependências/runners idênticos ao objeto final; só a especificação E2E mudou depois. |
| build-provenance.json | Registro intermediário do candidato de testesc7b45f4. A ligação FINAL está em frozen-n2.json e MATRIZ-N2-A2.json. |
| n2-a2-fluxo003/005.*, regressions-interrupted-infra.json | Rodada concorrente com build; falhas de inicialização de worker antes de coleta completa; não prova suites completas. Logs preservados. serial-* são as execuções posteriores válidas. |
| n2-a2-fluxo006.* | Suite completa70/70 em50d5d55; produto idêntico ao final. A cadeia ratificada repete as52 provas declaradas de retirada/hook no SHA final. |
| n2-a2-e2e-n2.*, e2e-preflight-* | Primeiras provas novas assumiam sheet visível após projeção bloqueada e depois selector exato incorreto. DOM demonstrava orientação correta. Falhas/contextos preservados, sem apagar asserts financeiros originais. |
| n2-a2-e2e-n2-authority.* | Três cenários mistos + auth verdes emc7b45f4 com última alteração só na nova prova E2E ainda não commitada. Preparatório. |
| frozen-n2.json | Congela d5570e8; hash da prova E2E e dos dois arquivos de produto; liga build50d5d55 e delta exclusivo de teste. |
| n2-a2-final-eslint.*, n2-a2-serial-*, n2-a2-ratified.*, n2-a2-e2e-*-final.*, n2-a2-official-check.* | Execuções finais sobre d5570e8 limpo e imutável. Cadeia ratificada/raw e check oficial são provas separadas do mesmo comando/SHA; a matriz consolida resultados sem esconder exits não zero. |
| preview-nominal-comparison.json |325/10; comparação usa ancestorTitles+title completos do JSON, pois fullName concatena sem separador. Asserções e logs não mudaram. |
| preservation-final.json, old-packet-verifier.* |320 arquivos/50 snapshots do pacote665583a verificados;178 evidências rastreadas anteriores e ZIP rev7 íntegros. |
| aep-active-before/after-base-refresh.json, aep-open/status-base-refresh.* | Status/open idempotente oficial após merge atualiza somente base_commit; contador2/3, histórico e demais campos preservados. |

O ZIP novo reúne esses registros e os preparatórios históricos. Contagens positivas, falhas históricas e provas invalidadas têm identidades distintas. O verificador confere hashes/bytes/snapshots, sem fabricar R ou reexecutar testes financeiros. Não houve consulta a provedores/cota nesta retomada.
