# Test info

- Name: V4 Entrega de dias atrás pelo caminho canônico; depois Corrigir datas desloca a garantia sem refazer nada
- Location: C:\Projetos\omni-gestao-ops-v4-frg-002\e2e\specs\ops-datas-retroativas-001.spec.ts:312:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "Entrega real em 08/10/2026: ao confirmar, a OS será marcada como entregue no histórico. Confirmar?"
Received: "Entrega real em 08/10/2026, retirada por Cliente QA Entrega mv44dbso: ao confirmar, a OS será marcada como entregue no histórico. Confirmar?"
    at C:\Projetos\omni-gestao-ops-v4-frg-002\e2e\specs\ops-datas-retroativas-001.spec.ts:369:19
```

# Page snapshot

```yaml
- complementary "Navegação principal":
  - button "Expandir menu":
    - img "OmniGestão"
  - text: OmniGestão Pro Workspace em foco
  - navigation:
    - text: Workspace
    - link "Painel Inicial":
      - /url: /dashboard
    - link "IA Mestre":
      - /url: /dashboard/ia-mestre
    - link "Omni Agent HUB":
      - /url: /dashboard/omni-agent
    - text: Hubs
    - link "Operações HUB":
      - /url: /dashboard/operacoes-v3
    - link "Operações V4 · Beta":
      - /url: /dashboard/operacoes-v4-preview
    - link "Operações V2":
      - /url: /dashboard/operacoes-v2
    - link "WhatsApp HUB":
      - /url: /dashboard/whatsapp
    - link "Cadastros HUB":
      - /url: /dashboard/cadastros-v2
    - link "Inventário Assistido":
      - /url: /dashboard/estoque/inventario
    - link "Catálogo de Aparelhos":
      - /url: /dashboard/catalogo-aparelhos
    - link "Vendas HUB":
      - /url: /dashboard/vendas-hub
    - link "Histórico de Caixa":
      - /url: /dashboard/caixa/historico
    - link "Financeiro HUB":
      - /url: /dashboard/financeiro-v2
    - link "Contador HUB":
      - /url: /dashboard/contador
    - link "Relatórios":
      - /url: /dashboard/relatorios
    - text: Administração
    - link "Master Console":
      - /url: /dashboard/master-console
    - link "Gestão da Rede":
      - /url: /dashboard/unidades
    - link "Configurações":
      - /url: /dashboard/configuracoes
  - text: Servidor conectado
- banner:
  - navigation: Matriz / Central de Operações
  - textbox "Pesquisa rápida (Alt+K) — Command Menu"
  - text: ⌘K
  - 'button "Tema atual: Black. Abrir seletor de temas"'
  - button "Alta legibilidade"
  - link "Sem créditos. Abrir consulta e compra de créditos":
    - /url: /dashboard/creditos
    - text: Sem créditos Comprar
  - button
  - button "Novo"
  - text: OD Operador QA Datas qa-frg-002@omni.test
  - heading "Buscar Rota ou Ação" [level=2]
  - paragraph: Digite um comando de navegação para executar rápido.
- main:
  - text: O OmniGestão Operações V4 · Beta operacional
  - button "Ir para OS, cliente, IMEI… ⌘K":
    - img
    - text: Ir para OS, cliente, IMEI… ⌘K
  - button "Sair do foco":
    - img
    - text: Sair do foco
  - text: Loja ativa
  - button "+ Novo"
  - complementary "Módulos de Operações V4":
    - button "Expandir módulos": V4
    - text: OPERAÇÕES
    - button "Visão geral":
      - img
      - text: Visão geral
    - button "Fila":
      - img
      - text: Fila
    - button "OS":
      - img
      - text: OS
    - button "Bancada":
      - img
      - text: Bancada
    - button "SLA":
      - img
      - text: SLA
    - button "Receber":
      - img
      - text: Receber
    - button "Garantias":
      - img
      - text: Garantias
    - button "Configurações":
      - img
      - text: Configurações
  - button "Contexto da OS"
  - heading "OS-QA-DATAS-mv44dbso" [level=1]
  - text: Entregue
  - button "Técnico Sem técnico"
  - button "Prioridade Normal"
  - button "Comercial R$ 100,00 · Aprovado"
  - button "Financeiro Quitado"
  - button "Pós-venda Garantia até 06/01"
  - button "Docs ▾"
  - button "Histórico 3 eventos"
  - button "⋯"
  - navigation "Pipeline operacional da OS":
    - button "✓ Entrada"
    - button "✓ Diagnóstico"
    - button "✓ Execução"
    - button "✓ Entrega"
    - button "● Pós-venda"
  - region "Próxima ação da OS":
    - paragraph: Concluído Fluxo operacional concluído
    - paragraph: A OS foi entregue ao cliente. Garantia e retornos ficam no pós-venda.
    - button "Abrir pós-venda"
  - region "Guia de retirada":
    - text: "Conferir retirada OS-QA-DATAS-mv44dbso Entregue Cliente QA Entrega mv44dbso — Moto G QA Serviço aprovado: Troca de tela QA"
    - status: Quitado Pagamento quitado.
    - text: Total R$ 100,00 Recebido R$ 100,00 Saldo R$ 0,00
    - term: Garantia
    - definition: 90 dias Vigente
    - term: Acessórios em custódia
    - definition: Nenhum registrado na entrada
    - term: Fotos de saída
    - definition: Nenhuma registrada
  - text: 📦 Registro de entrega Entregue Retirado por Cliente QA Entrega mv44dbso Data da entrega 08/10/2026 Registrado no sistema 11/10/2026 14:51
  - button "Corrigir datas"
  - text: Assinatura de retirada Colete a assinatura de quem retirou o equipamento.
  - button "Limpar" [disabled]
  - button "Salvar assinatura" [disabled]
  - group: Linha do tempo da entrega (1)
  - text: Fotos de saída Opcional
  - button "Adicionar fotos de saída"
  - complementary "Garantia e documentos da OS":
    - text: 🛡 Garantia da OS Vigente Prazo 90 dias Cobertura Tela/touch instalada nesta assistência contra defeitos de funcionamento (falhas de toque, linhas, manchas ou ausência de imagem) não decorrentes de mau uso. Início 08/10/2026 Validade 06/01/2027 Editar garantia Modelo de garantia
    - combobox "Modelo de garantia":
      - option "Garantia — Troca de tela" [selected]
      - option "Garantia — Troca de bateria"
      - option "Garantia — Conector de carga"
      - option "Garantia — Câmera"
      - option "Garantia — Alto-falante"
      - option "Garantia — Microfone"
      - option "Garantia — Serviço de software"
      - option "Garantia — Reparo de placa"
      - option "Sem garantia — Oxidação / contato com líquido"
      - option "Sem garantia"
      - option "Garantia — Personalizada"
    - text: Prazo em dias
    - spinbutton "Prazo em dias": "90"
    - button "Salvar garantia" [disabled]
    - text: A garantia fica prevista na OS e passa a valer na entrega. Documentos
    - button "Imprimir Termo de Garantia"
    - button "Imprimir Termo de Entrega"
    - button "Imprimir OS (cliente)"
    - text: Reimpressão abre o mesmo documento. WhatsApp no modal, quando o cliente tiver telefone válido.
  - complementary "Atividade da OS":
    - button "Expandir atividade da OS"
    - text: ATIVIDADE DA OS ATIVIDADE
    - paragraph: Comunicação, anexos e histórico relacionados à OS atual.
    - text: Comunicação
    - button "Enviar atualização no WhatsApp"
    - text: Anexos 0 Nenhum anexo disponível.
    - button "Abrir histórico do cliente"
  - text: ✓ Entrega confirmada.
- region "Notifications (F8)":
  - list
- alert
```

# Test source

```ts
  269 |     await lancar(page, "Atendimento rápido");
  270 |     const modal = page.getByRole("dialog").filter({ hasText: "Serviço simples, pagamento e conclusão na hora." });
  271 |     await expect(modal).toHaveCount(1);
  272 |     await expect(modal.getByText("Caixa aberto", { exact: true })).toBeVisible();
  273 |     await modal.getByRole("button", { name: "Novo", exact: true }).click();
  274 |     await modal.getByPlaceholder("Nome do cliente").fill(cliente);
  275 |     await modal.getByRole("button", { name: "Instalação de película", exact: true }).click();
  276 |     const datas = modal.getByRole("region", { name: "Datas do atendimento" });
  277 |     await expect(datas.getByLabel(/^Data do atendimento/)).toHaveValue(diaLoja(0));
  278 |     await datas.getByLabel(/^Data do atendimento/).fill(dia);
  279 |     await expect(datas.getByText("A data informa quando o serviço aconteceu. A confirmação registra o recebimento agora, no caixa atual.", { exact: true })).toBeVisible();
  280 |     await capturar(page, datas, "atendimento-datas");
  281 |
  282 |     const aviso = await confirmarNativo(page, () => modal.getByRole("button", { name: "Finalizar e emitir recibo" }).click());
  283 |     expect(aviso).toContain(`com data de ${br(dia)}`);
  284 |     expect(aviso).toContain("O recebimento é registrado agora, no caixa atual.");
  285 |     await expect(modal).toBeHidden();
  286 |
  287 |     const rows = await osDoCliente(prisma, cliente);
  288 |     expect(rows).toHaveLength(1);
  289 |     const p = rows[0]!.payload as Json;
  290 |     const ar = p.atendimentoRapidoV3;
  291 |     expect(naLoja(ar.concluidoEm)).toBe(`${dia} 12:00`);
  292 |     expect(ar.concluidoEmMeta).toEqual({ precisao: "dia", dia });
  293 |     expect(pertoDeAgora(ar.registradoEm)).toBe(true);
  294 |     expect(p.aberturaV3.recepcao.dataEntradaMeta).toEqual({ precisao: "dia", dia });
  295 |     // Timeline com o horário real; a data efetiva vai em campo próprio.
  296 |     const evento = (p.timeline as Json[]).find((e) => e.metadata?.atendimentoRapido === true);
  297 |     expect(evento).toBeTruthy();
  298 |     expect(pertoDeAgora(evento!.criadoEm)).toBe(true);
  299 |     expect(evento!.metadata.concluidoEm).toBe(ar.concluidoEm);
  300 |     // Pagamento nunca retrodatado: operação no caixa aberto, com o horário de agora.
  301 |     const caixa = await prisma.caixaOperacao.findMany({ where: { storeId: LOJA, payload: { path: ["ordemServicoId"], equals: rows[0]!.id } } });
  302 |     expect(caixa).toHaveLength(1);
  303 |     expect(caixa[0]!.sessaoId).toBe(sessao.id);
  304 |     expect(caixa[0]!.valor).toBe(20);
  305 |     expect(pertoDeAgora(caixa[0]!.at.toISOString())).toBe(true);
  306 |     console.log(`QA_DATAS_ATENDIMENTO: os=${rows[0]!.id} servico=${dia} caixa_at=${caixa[0]!.at.toISOString()}`);
  307 |   } finally {
  308 |     await prisma.$disconnect();
  309 |   }
  310 | });
  311 |
  312 | test("V4 Entrega de dias atrás pelo caminho canônico; depois Corrigir datas desloca a garantia sem refazer nada", async ({ page }) => {
  313 |   test.setTimeout(240_000);
  314 |   const prisma = new PrismaClient({ datasourceUrl: bancoDescartavel() });
  315 |   const m = marca();
  316 |   const codigo = `OS-QA-DATAS-${m}`;
  317 |   const entrada = diaLoja(-10);
  318 |   const entrega = diaLoja(-3);
  319 |   const corrigida = diaLoja(-2);
  320 |   try {
  321 |     const sessao =
  322 |       (await prisma.sessaoCaixa.findFirst({ where: { storeId: LOJA, status: "ABERTA" } })) ??
  323 |       (await prisma.sessaoCaixa.create({ data: { storeId: LOJA, status: "ABERTA", operador: "QA Datas" } }));
  324 |     const entradaIso = new Date(`${entrada}T15:00:00.000Z`).toISOString();
  325 |     const id = `qa-datas-entrega-${m}`;
  326 |     const agora = new Date().toISOString();
  327 |     const os = await prisma.ordemServico.create({
  328 |       data: {
  329 |         id, storeId: LOJA, numero: codigo, status: "Pronto", equipamento: "Moto G QA", defeito: "Tela QA", valorTotal: 100,
  330 |         payload: {
  331 |           id, codigo, storeId: LOJA, clienteId: "", criadoEm: agora, atualizadoEm: agora, prioridade: "media", origem: "balcao",
  332 |           pecas: [], observacoes: [], anexos: [],
  333 |           cliente: { id: "", nome: `Cliente QA Entrega ${m}` }, equipamento: { tipo: "Smartphone", marca: "Moto", modelo: "G QA", defeitoRelatado: "Tela QA" },
  334 |           status: "pronta", operacaoStatusV3: "pronta", valorTotal: 100, garantia: { ativa: false, prazoDias: 90 },
  335 |           orcamento: { id: `orc-${m}`, status: "aprovado", pecas: [], servicos: [{ id: "s1", descricao: "Troca de tela QA", valor: 100 }], desconto: 0, total: 100, criadoEm: new Date().toISOString() },
  336 |           aberturaV3: {
  337 |             versao: 1,
  338 |             recepcao: { dataEntrada: entradaIso, dataEntradaMeta: { precisao: "dia", dia: entrada }, origem: "balcao" },
  339 |             garantiaPrevista: { modelo: "tela", label: "Troca de Tela", prazoDias: 90 },
  340 |           },
  341 |           timeline: [],
  342 |         },
  343 |       },
  344 |     });
  345 |
  346 |     // Recebimento real AGORA, no caixa aberto (o guard da entrega exige quitação).
  347 |     await abrirOS(page, codigo);
  348 |     await page.getByRole("button").and(page.getByTitle("Financeiro", { exact: true })).click();
  349 |     await page.getByRole("button", { name: /^Receber R\$\s100,00$/ }).click();
  350 |     const receber = page.getByRole("dialog", { name: "Receber pagamento" });
  351 |     await receber.getByLabel("Forma da linha 1").selectOption("dinheiro");
  352 |     await expect(receber.getByLabel("Valor da linha 1")).toHaveValue("100");
  353 |     await receber.getByRole("button", { name: /Confirmar R\$\s100,00/ }).click();
  354 |     await expect(receber).toBeHidden();
  355 |     await page.getByRole("button", { name: "Fechar", exact: true }).click();
  356 |     const caixaAntes = await prisma.caixaOperacao.findMany({ where: { storeId: LOJA, payload: { path: ["ordemServicoId"], equals: os.id } } });
  357 |     expect(caixaAntes).toHaveLength(1);
  358 |     expect(caixaAntes[0]!.sessaoId).toBe(sessao.id);
  359 |
  360 |     // Entrega com data efetiva anterior.
  361 |     await page.getByRole("navigation", { name: "Pipeline operacional da OS" }).getByRole("button", { name: /Entrega/ }).click();
  362 |     const campo = page.getByLabel(/^Data da entrega/);
  363 |     await expect(campo).toHaveValue(diaLoja(0));
  364 |     await expect(page.getByText(/Quando o aparelho foi realmente entregue ao cliente\./)).toBeVisible();
  365 |     await campo.fill(entrega);
  366 |     await expect(page.getByText("Entrega com data anterior. O histórico guarda também o horário real deste registro.", { exact: true })).toBeVisible();
  367 |     await capturar(page, campo.locator("xpath=ancestor::div[.//button[normalize-space()='Confirmar entrega real']][1]"), "entrega-data");
  368 |     const aviso = await confirmarNativo(page, () => page.getByRole("button", { name: "Confirmar entrega real" }).click());
> 369 |     expect(aviso).toBe(`Entrega real em ${br(entrega)}: ao confirmar, a OS será marcada como entregue no histórico. Confirmar?`);
      |                   ^ Error: expect(received).toBe(expected) // Object.is equality
  370 |     // "Confirmando…" também tira o rótulo do botão: espera o fim real da ação no servidor.
  371 |     await expect(page.getByRole("button", { name: /^(Confirmar entrega real|Confirmando…)$/ })).toHaveCount(0, { timeout: 60_000 });
  372 |     const lerOS = async () => (await prisma.ordemServico.findUniqueOrThrow({ where: { id: os.id } })).payload as Json;
  373 |     await expect.poll(async () => (await lerOS()).operacaoStatusV3, { timeout: 30_000 }).toBe("entregue");
  374 |
  375 |     const aposEntrega = await lerOS();
  376 |     expect(naLoja(aposEntrega.entregaV3.entregueEm)).toBe(`${entrega} 12:00`);
  377 |     expect(aposEntrega.entregaV3.entregueEmMeta).toEqual({ precisao: "dia", dia: entrega });
  378 |     expect(pertoDeAgora(aposEntrega.entregaV3.registradoEm)).toBe(true);
  379 |     expect(aposEntrega.entregueEm).toBe(aposEntrega.entregaV3.entregueEm);
  380 |     expect(aposEntrega.retirada.retiradoEm).toBe(aposEntrega.entregaV3.entregueEm);
  381 |     const eventosEntrega = (aposEntrega.timeline as Json[]).filter((e) => e.tipo === "entrega_cliente");
  382 |     expect(eventosEntrega).toHaveLength(1);
  383 |     expect(pertoDeAgora(eventosEntrega[0]!.criadoEm)).toBe(true);
  384 |     expect(eventosEntrega[0]!.metadata).toMatchObject({ entregueEm: aposEntrega.entregaV3.entregueEm, entregaRetroativa: true, precisao: "dia" });
  385 |     // O pagamento continua com o horário real em que aconteceu.
  386 |     expect(pertoDeAgora(caixaAntes[0]!.at.toISOString())).toBe(true);
  387 |     await expect(page.getByText("Data da entrega", { exact: true }).locator("..")).toContainText(br(entrega));
  388 |     await sairDoFoco(page);
  389 |     await expect(contexto(page, "Entrada")).toContainText(br(entrada));
  390 |     await expect(contexto(page, "Entrada")).not.toContainText("12:00");
  391 |     await expect(contexto(page, "Entrega")).toContainText(br(entrega));
  392 |
  393 |     // Correção posterior: só a data; nada é entregue, cobrado ou registrado de novo.
  394 |     await page.getByTitle("Mais ações").click();
  395 |     await page.getByText("Ações da OS", { exact: true }).locator("..").getByRole("button", { name: /Corrigir datas/ }).click();
  396 |     const dlg = page.getByRole("dialog", { name: new RegExp(`Corrigir datas · ${codigo}`) });
  397 |     await expect(dlg).toBeVisible();
  398 |     const campoEntrega = dlg.getByLabel(/^Data da entrega/);
  399 |     await expect(campoEntrega).toHaveValue(entrega);
  400 |     await campoEntrega.fill(corrigida);
  401 |     const impacto = dlg.getByRole("region", { name: "Impacto na garantia" });
  402 |     await expect(impacto).toBeVisible();
  403 |     await dlg.getByPlaceholder("Ex.: o aparelho foi entregue na sexta e só registrei hoje.").fill("Data digitada errada no balcão.");
  404 |     await capturar(page, dlg, "corrigir-datas");
  405 |     // Sem a confirmação explícita da garantia nada é enviado (mesma regra do servidor).
  406 |     await dlg.getByRole("button", { name: "Salvar correção" }).click();
  407 |     await expect(dlg.getByText("Confira o impacto na garantia e confirme antes de salvar.")).toBeVisible();
  408 |     await expect(impacto.getByRole("checkbox")).toBeFocused();
  409 |     await impacto.getByRole("checkbox", { name: /Confirmo que a garantia passa a contar da nova data de entrega\./ }).check();
  410 |     await dlg.getByRole("button", { name: "Salvar correção" }).click();
  411 |     await expect(dlg).toBeHidden();
  412 |
  413 |     const final = (await prisma.ordemServico.findUniqueOrThrow({ where: { id: os.id } })).payload as Json;
  414 |     expect(naLoja(final.entregaV3.entregueEm)).toBe(`${corrigida} 12:00`);
  415 |     expect(final.entregaV3.entregueEmMeta).toEqual({ precisao: "dia", dia: corrigida });
  416 |     expect(final.entregueEm).toBe(final.entregaV3.entregueEm);
  417 |     expect(final.retirada.retiradoEm).toBe(final.entregaV3.entregueEm);
  418 |     // Registro original preservado; nenhum novo evento de entrega; auditoria agora.
  419 |     expect(final.entregaV3.registradoEm).toBe(aposEntrega.entregaV3.registradoEm);
  420 |     expect((final.timeline as Json[]).filter((e) => e.tipo === "entrega_cliente")).toHaveLength(1);
  421 |     const correcoes = (final.timeline as Json[]).filter((e) => e.metadata?.evento === "datas_corrigidas");
  422 |     expect(correcoes).toHaveLength(1);
  423 |     expect(pertoDeAgora(correcoes[0]!.criadoEm)).toBe(true);
  424 |     expect(correcoes[0]!.metadata.motivo).toBe("Data digitada errada no balcão.");
  425 |     expect(correcoes[0]!.metadata.campos).toEqual([{ campo: "dataEntrega", antes: aposEntrega.entregaV3.entregueEm, depois: final.entregaV3.entregueEm }]);
  426 |     expect(correcoes[0]!.metadata.garantia).toMatchObject({ inicioAntes: expect.any(String), inicioDepois: expect.any(String) });
  427 |     // Nada financeiro refeito.
  428 |     const caixaDepois = await prisma.caixaOperacao.findMany({ where: { storeId: LOJA, payload: { path: ["ordemServicoId"], equals: os.id } } });
  429 |     expect(caixaDepois.map((c) => c.id)).toEqual(caixaAntes.map((c) => c.id));
  430 |     expect(final.pagamentoV3).toEqual(aposEntrega.pagamentoV3);
  431 |     await expect(contexto(page, "Entrega")).toContainText(br(corrigida));
  432 |     await expect(page.getByText("Data da entrega", { exact: true }).locator("..")).toContainText(br(corrigida));
  433 |     await page.screenshot({ path: test.info().outputPath("entrega-corrigida-1440.png") });
  434 |     console.log(`QA_DATAS_ENTREGA: os=${os.id} entrega=${entrega} corrigida=${corrigida} caixa=${caixaAntes[0]!.id}`);
  435 |   } finally {
  436 |     await prisma.$disconnect();
  437 |   }
  438 | });
  439 |
  440 | test("V3 (paridade): OS entregue mostra as datas efetivas no workspace; Corrigir datas da V3 grava só a entrada", async ({ page }) => {
  441 |   test.setTimeout(180_000);
  442 |   const prisma = new PrismaClient({ datasourceUrl: bancoDescartavel() });
  443 |   const m = marca();
  444 |   const id = `qa-datas-v3-${m}`;
  445 |   const codigo = `OS-QA-V3-${m}`;
  446 |   const entrada = diaLoja(-10);
  447 |   const previsao = diaLoja(-5);
  448 |   const entrega = diaLoja(-3);
  449 |   const novaEntrada = diaLoja(-12);
  450 |   // Âncora técnica só-dia = 12:00 em São Paulo (UTC-3, sem horário de verão).
  451 |   const ancora = (dia: string) => new Date(`${dia}T15:00:00.000Z`).toISOString();
  452 |   const agora = new Date().toISOString();
  453 |   try {
  454 |     await prisma.ordemServico.create({
  455 |       data: {
  456 |         id, storeId: LOJA, numero: codigo, status: "Entregue", equipamento: "Moto G QA", defeito: "Tela QA", valorTotal: 0,
  457 |         payload: {
  458 |           id, codigo, storeId: LOJA, clienteId: "", criadoEm: agora, atualizadoEm: agora, prioridade: "media", origem: "balcao",
  459 |           pecas: [], observacoes: [], anexos: [], garantia: { ativa: false },
  460 |           cliente: { id: "", nome: `Cliente QA V3 ${m}` }, equipamento: { tipo: "Smartphone", marca: "Moto", modelo: "G QA", defeitoRelatado: "Tela QA" },
  461 |           status: "entregue", operacaoStatusV3: "entregue",
  462 |           aberturaV3: {
  463 |             versao: 1, criadoEm: agora,
  464 |             recepcao: {
  465 |               dataEntrada: ancora(entrada), dataEntradaMeta: { precisao: "dia", dia: entrada },
  466 |               previsaoEntrega: ancora(previsao), previsaoEntregaMeta: { precisao: "dia", dia: previsao }, origem: "balcao",
  467 |             },
  468 |           },
  469 |           sla: { prazo: ancora(previsao), status: "ok", origemV3: "informada" },
```