# N2 — classificação do executor e escopo do corretivo

O proprietário informou parecer preliminar GLM/Z.ai com P0=0/P1=0/P2=0/P3=8. O texto integral desse parecer, incluindo N1/N3, não foi fornecido nesta retomada; não se inventam conteúdos ou aceites. Ele não é R oficial e não aprova o código alterado.

Classificação técnica do executor: **P2**, quebra explícita do contrato A do GOAL002, que exige mensagem e destino no PDV V3 via recebimento simples/misto. A resposta/persistência/replay mistos já conservavam comercial={codigo,destino}; o hook descartava o campo e o fallback local V3 só cobria pendente/recusado/expirado. PRECO_AUSENTE e VALORES_DIVERGENTES perdiam o destino. Não se demonstrou duplicação de cobrança pelo N2.

A prova vermelha sobre produto idêntico a 665583a (HEAD documental 86cbd77) falhou em 15 casos; outros14 passaram e42 foram filtrados por -t N2. A primeira correção do hook passou no hook/V3/PG, mas os dois montados V4 ainda falharam: o wrapper recarregava o hook após recusa, iniciando outra visita e apagando o motivo. Esse achado é parte do mesmo caminho N2 e está na allowlist. A correção final preserva a orientação terminal canônica no hook e evita o reload destrutivo do hook na recusa comercial V4; lista, detalhe e projeção financeira continuam sendo relidos. Não há navegação automática.

36 provas N2 verdes: 25 de hook,2 V3,7 V4,2 PostgreSQL reais. Os testes de metadados, incerteza, outra instância, troca de loja/OS, A–B–A, sucesso/recusa posterior e reload/reabertura impedem orientação obsoleta e não transformam metadado em prova financeira.

AEP oficial: attempt --fail registrou o N2 como falha da tentativa1; corretivo na tentativa2/3, MESMO GOAL, plan_rev8, sem novo open ou replanejamento. Sem edição manual de state/ledger/REGISTRY/executors. N1/N3 e os cinco P3 anteriores continuam sujeitos à nova R, sem corretivo ou aceite implícito.

Integração normal de origin/main 1fd9090:12 paths (PDV legado/paridade e planejamento fiscal), nenhum em Operações V3/V4, testes deste fluxo, dependências ou executores. Merge50d5d55 sem conflitos. O check de665583a permanece prova somente daquele SHA. A checagem preparatória tsc terminou com código0, mas o runner retornou1 porque o HEAD mudou durante sua execução; prova invalidada, preservada e não contabilizada.

Novo build/regressões/check estão sendo coletados sob o SHA integrado; publicação/close/GOAL003/008/datas retroativas permanecem proibidos antes de R elegível APPROVE.
