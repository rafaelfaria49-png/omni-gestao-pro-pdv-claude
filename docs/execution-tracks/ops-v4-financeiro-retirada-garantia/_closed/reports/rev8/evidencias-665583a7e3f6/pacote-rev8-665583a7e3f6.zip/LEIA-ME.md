# GOAL002 — pacote imutável da revisão 8

Objeto funcional: 665583a7e3f6f1b9552b4c56b3d6a3dd97299167. Base integrada da PR: 9f1b511a21ab98a924513428d465725e6839fdc2. Base histórica de comparação: 98ef7172a915713ad177207112f6aff3db9801a1. Corretivo P2 reproduzido antes em cd69780c81b3bc159cd5f0810daabc98aae06a34.

O índice ARQUIVOS-REVISAO.json contém os 50 arquivos funcionais alterados pelo GOAL A–E, incluindo as revisões anteriores. DIFF-FUNCIONAL-A-E.patch e os diffs individuais são o mesmo conjunto. DIFF-CORRETIVO-REV8.patch identifica apenas o delta novo desde cd69780. As fontes Git completas são texto .txt para não poluir o typecheck da worktree.

LEITURA-OBRIGATORIA.json lista todos os diffs individuais integrais e todas as fontes completas de testes/runners modificados. Os chunks evitam limite de saída do Read; não são amostras. A auditoria da R conferirá chamadas e retornos reais. Produto também tem fontes completas para contexto. Ler a lista inteira é requisito do gate, não apenas emitir alegação de cobertura.

MANIFEST.json autentica cada arquivo. packet-seal.json e o ZIP ficam fora deste diretório para evitar autorreferência. O verificador somente leitura confere manifesto, bytes e SHA-256, snapshots contra Git no SHA congelado e ZIP. A R deve executar esse comando autorizado e registrar o resultado.

validacao/MATRIZ-REV8.json conserva comandos, SHA, banco/host/porta efetivamente consultados, exits, contagens e hashes de stdout/stderr. Logs brutos não foram filtrados. No preview completo as falhas podem incluir enormes dumps de fonte; conferir nomes, asserções e footer nos logs sem confundir isso com leitura do diff funcional. Preparatórias e setup-failures estão preservados com identidade própria e não contam como check aprovado.

O runner de baseline teve uma falha inicial de preparação porque tentou calcular hash de arquivo inexistente na base. Ela ocorreu antes da coleta; a repetição corrigida é a referência válida e o resumo inicial permanece preservado. O build preparatório teve EPERM da DLL Prisma por processo próprio ainda carregado; o probe passou a um processo curto separado. O fonte financeiro não mudou nessas correções de runner. Os snapshots ignorados da proposta rev7 foram apenas renomeados para .snapshot.txt, com hashes idênticos documentados; ZIP, manifesto e relatórios rev7 estão intactos.

T56c não está verde: preservar execução completa base/candidato e todas as observações isoladas, inclusive os timeouts de espera da trava no candidato. Fontes iguais não provam causa do interleaving. Nenhum skip/fixme, retry para obter verde ou alteração do teste foi feito. Falhas preexistentes de preview/#235/#237 devem ser conferidas na comparação atual, sem aprovação automática por rotulagem.

A revisão é somente leitura, sem .env/segredos/produção/writers/migrations. O executor é OpenAI, C4 ALTO; a R precisa ser Anthropic em sessão nova. A R deve distinguir inspeção de código, leitura de evidências e testes efetivamente reexecutados (neste ambiente de R, nenhum). Os cinco P3 da R anterior continuam sujeitos a avaliação explícita; não foram implementados. Close, retirada de draft e publicação aguardam APPROVE P0=P1=P2=0 com cobertura suficiente.

Na preparação, node --check detectou um parêntese excedente no auditor de cobertura local ignorado. Foi corrigido antes de iniciar a R; diagnóstico e exit 1 preservados em scripts-evidencia-syntax-preparatoria.*, e os oito scripts passaram depois. O candidato funcional e a tentativa oficial não foram alterados.
